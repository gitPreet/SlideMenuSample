//
//  UIStoryboard+Additions.m
//  SideMenu
//
//  Created by Preetham Baliga on 13/11/2015.
//

#import "UIStoryboard+Additions.h"

@implementation UIStoryboard (Additions)

+ (UIStoryboard *)mainStoryboard
{
    return [UIStoryboard storyboardWithName:@"Main" bundle:nil];
}

@end
