//
//  UIStoryboard+Additions.h
//  SideMenu
//
//  Created by Preetham Baliga on 13/11/2015.
//

#import <UIKit/UIKit.h>

@interface UIStoryboard (Additions)

+ (UIStoryboard *)mainStoryboard;

@end
