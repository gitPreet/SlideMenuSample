//
//  SMBaseModel.m
//  SideMenu
//
//  Created by Preetham Baliga on 11/11/2015.
//

#import "SMBaseModel.h"

@implementation SMBaseModel

@end
