//
//  SMBaseViewController.h
//  SideMenu
//
//  Created by Preetham Baliga on 11/11/2015.
//

#import <UIKit/UIKit.h>

@interface SMBaseViewController : UIViewController

@end
