//
//  SMBaseCollectionViewCell.h
//  SideMenu
//
//  Created by Preetham Baliga on 11/11/2015.
//

#import <UIKit/UIKit.h>
#import "SMBaseModel.h"

@interface SMBaseCollectionViewCell : UICollectionViewCell

@property (strong, nonatomic) SMBaseModel *model;

@end
