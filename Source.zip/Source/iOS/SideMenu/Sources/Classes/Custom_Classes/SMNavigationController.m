//
//  SMNavigationController.m
//  SideMenu
//
//  Created by Preetham Baliga on 12/11/2015.
//

#import "SMNavigationController.h"
#import "SMFriendsDetailController.h"
#import "SMAppDelegate.h"

@interface SMNavigationController ()

@property (nonatomic) BOOL isMenuOpen;
@property (strong, nonatomic) UIPanGestureRecognizer *panGesture;
@property (nonatomic) BOOL shouldShowMenu;

@end

@implementation SMNavigationController

static SMNavigationController *sharedInstance = nil;

+ (SMNavigationController *)sharedInstance
{
    if(!sharedInstance)
    {
        NSLog(@"NavigationController has not been initialized. Either place one in your storyboard or initialize one in code");
    }
    return sharedInstance;
}

#pragma mark - Initialization Methods

- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if(self)
    {
        [self setUp];
    }
    return self;
}

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if(self)
    {
        [self setUp];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - SetUp

- (void)setUp
{
    sharedInstance = self;
    self.delegate = self;
    self.isMenuOpen = NO;
    self.shouldShowMenu = NO;
    self.panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panGestureDetected:)];
        [self.view addGestureRecognizer:self.panGesture];

    [self.view.layer setShadowColor:[UIColor blackColor].CGColor];
    [self.view.layer setShadowOpacity:0.8];
}

- (void)setMenuScreenController:(SMMenuScreenController *)menuScreenController
{
    [menuScreenController.view removeFromSuperview];
    _menuScreenController = menuScreenController;
}

- (void)resetMenuView
{
    [UIView animateWithDuration:0.25f
                          delay:0
                        options:UIViewAnimationOptionBeginFromCurrentState
                     animations:^
     {
            self.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
     }
                     completion:^(BOOL finished)
     {
         self.isMenuOpen = NO;
     }];
}

#pragma mark - Gesture Related Methods

- (void)panGestureDetected:(UIPanGestureRecognizer *)panGesture
{
    if(self.shouldShowMenu)
    {
        CGFloat menuTableWidth = [self.menuScreenController menuTableSize].width;
        CGPoint translation = [panGesture translationInView:self.view];
        CGPoint location = [panGesture locationInView:self.view];
        [self.view.window insertSubview:self.menuScreenController.view atIndex:0];

        switch(panGesture.state)
        {
            case UIGestureRecognizerStateBegan:
            {
                break;
            }
            case UIGestureRecognizerStateChanged:
            {
                if(!self.isMenuOpen)
                {
                    if(translation.x <= menuTableWidth && translation.x >= 0)
                    {
                        CGRect frame = self.view.frame;
                        frame.origin.x = translation.x;
                        self.view.frame = frame;
                    }
                }
                else
                {
                    if(location.x < 5)
                    {
                        CGRect frame = self.view.frame;
                        frame.origin.x += location.x;
                        self.view.frame = frame;
                    }
                }
                break;
            }
            case UIGestureRecognizerStateEnded:
            {
                if(self.view.frame.origin.x < menuTableWidth/2)
                {
                    [self resetMenuView];
                }
                else
                {
                    [UIView animateWithDuration:0
                                          delay:0
                                        options:UIViewAnimationOptionBeginFromCurrentState
                                     animations:^
                     {
                         
                         CGRect frame = self.view.frame;
                         frame.origin.x = menuTableWidth; //Width of the menu view
                         self.view.frame = frame;
                     }
                                     completion:^(BOOL finished)
                     {
                         self.isMenuOpen = YES;
                     }];
                }
                break;
            }
            default:
            {
                break;
            }
        }
    }
}

- (void)swipeGestureDetected:(UISwipeGestureRecognizer *)swipeGesture
{
    switch(swipeGesture.state)
    {
        case UIGestureRecognizerStateBegan:
        {
            NSLog(@"Swipe Began");
            break;
        }
        case UIGestureRecognizerStateChanged:
        {
            NSLog(@"Swipe Changed");
            break;
        }
        case UIGestureRecognizerStateEnded:
        {
            NSLog(@"Swipe Ended");
            break;
        }
        default:
        {
            break;
        }
    }
}

#pragma mark - UINavigation Controller Delegate

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    if(![viewController isKindOfClass:[SMFriendsDetailController class]])
    {
        viewController.navigationItem.leftBarButtonItem = [self leftBarButtonForMenu];
        self.shouldShowMenu = YES;
    }
}

#pragma mark - Creating Bar Button Items

- (UIBarButtonItem *)leftBarButtonForMenu
{
    UIBarButtonItem *customButtom = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"Menu_Button"]
                                                                     style:UIBarButtonItemStylePlain
                                                                    target:self action:@selector(leftMenuSelected:)];
    return customButtom;
}


#pragma mark - Bar Button Action Methods

- (void)leftMenuSelected:(id)sender
{
    if(self.isMenuOpen)
    {
        [self resetMenuView];
    }
    else
    {
        [self openMenuWithCompletion:nil];
    }
}

#pragma mark - Open & Close Menu

- (void)openMenuWithCompletion:(void (^) ())handler
{
    CGFloat menuTableWidth = [self.menuScreenController menuTableSize].width;

    [self.view.window insertSubview:self.menuScreenController.view atIndex:0];

    [UIView animateWithDuration:0.25f
                          delay:0
                        options:UIViewAnimationOptionBeginFromCurrentState
                     animations:^
    {
        
        CGRect frame = self.view.frame;
        frame.origin.x = menuTableWidth;
        self.view.frame = frame;
    }
                     completion:^(BOOL finished)
    {
        self.isMenuOpen = YES;
        [self.view.layer setShadowColor:[UIColor blackColor].CGColor];
        [self.view.layer setShadowOpacity:0.8];
    }];
}

- (void)dismissMenu
{
    [self resetMenuView];
}

#pragma mark - Switching View Controllers

- (void)switchToViewController:(SMBaseViewController *)viewController
{
    if(viewController)
    {
        NSArray *vcArray = self.viewControllers;
        for(SMBaseViewController *controller in vcArray)
        {
            [controller removeFromParentViewController];
        }

        [self resetMenuView];
        [self pushViewController:viewController animated:YES];
    }
}

@end
