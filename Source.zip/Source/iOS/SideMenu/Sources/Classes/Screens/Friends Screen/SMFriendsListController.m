//
//  SMFriendsListController.m
//  SideMenu
//
//  Created by Preetham Baliga on 11/11/2015.
//  Copyright © 2015 Preetham. All rights reserved.
//

#import "SMFriendsListController.h"
#import "SMNavigationController.h"

@interface SMFriendsListController () <UITableViewDataSource, UITableViewDelegate>

@end

@implementation SMFriendsListController

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.title = @"Friends";
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - UITableView Data Source Methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 15;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *friendsCell = [tableView dequeueReusableCellWithIdentifier:@"friendsListCell"];
    friendsCell.textLabel.text = [NSString stringWithFormat:@"Friend %ld",indexPath.row + 1];
    return friendsCell;
}

#pragma mark - UITableView Delegate Methods

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [[SMNavigationController sharedInstance] dismissMenu];
}

@end
