//
//  SMFriendsDetailController.h
//  SideMenu
//
//  Created by Preetham Baliga on 13/11/2015.
//  Copyright © 2015 Preetham. All rights reserved.
//

#import "SMBaseViewController.h"

@interface SMFriendsDetailController : SMBaseViewController

@end
