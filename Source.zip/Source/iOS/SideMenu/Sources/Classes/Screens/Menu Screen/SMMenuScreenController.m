//
//  SMMenuScreenController.m
//  SideMenu
//
//  Created by Preetham Baliga on 11/11/2015.
//  Copyright © 2015 Preetham. All rights reserved.
//

#import "SMMenuScreenController.h"
#import "SMNavigationController.h"
#import "SMFriendsListController.h"
#import "SMHomeScreenController.h"
#import "SMProfileScreenController.h"
#import "UIStoryboard+Additions.h"

@interface SMMenuScreenController () <UITableViewDataSource,UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UIView *tapRecogniserView;
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic, strong) UITapGestureRecognizer *tapGestureRecogniser;
@property (strong, nonatomic) NSMutableArray *menuOptions;

@end

@implementation SMMenuScreenController

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.tableView.tableFooterView = [UIView new];
    self.menuOptions = [NSMutableArray arrayWithObjects:@"Home",@"Friends",@"Profile", nil];
   // [self addGestureToView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (CGSize)menuTableSize
{
    return CGSizeMake(self.tableView.frame.size.width, self.tableView.frame.size.height);
}

- (void)addGestureToView
{
    self.tapGestureRecogniser = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissMenuScreen:)];
    [self.tapRecogniserView addGestureRecognizer:self.tapGestureRecogniser];
}

- (void)dismissMenuScreen:(UITapGestureRecognizer *)gestureRecogniser
{
    [[SMNavigationController sharedInstance] dismissMenu];
}

#pragma mark - UITableViewData Source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.menuOptions.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"menuCellIdentifier"];
    cell.textLabel.text = self.menuOptions[indexPath.row];
    cell.textLabel.font = [UIFont fontWithName:@"Helvetica-Neue" size:14.0f];
    return cell;
}

#pragma mark - UITableView Delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UIStoryboard *mainStoryboard = [UIStoryboard mainStoryboard];
    SMBaseViewController *controllerToShow = nil;

    switch(indexPath.row)
    {
        case 0:
        {
            controllerToShow = (SMHomeScreenController *)[mainStoryboard instantiateViewControllerWithIdentifier:@"SMHomeScreenController"];
            break;
        }
        case 1:
        {
            controllerToShow = (SMFriendsListController *)[mainStoryboard instantiateViewControllerWithIdentifier:@"SMFriendsListController"];
            break;
        }
        case 2:
        {
            controllerToShow = (SMProfileScreenController *)[mainStoryboard instantiateViewControllerWithIdentifier:@"SMProfileScreenController"];
            break;
        }
        default:
        {
            break;
        }
    }

    [[SMNavigationController sharedInstance] switchToViewController:controllerToShow];
}

@end
