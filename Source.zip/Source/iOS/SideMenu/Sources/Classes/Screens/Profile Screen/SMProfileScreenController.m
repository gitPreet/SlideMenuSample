//
//  SMProfileScreenController.m
//  SideMenu
//
//  Created by Preetham Baliga on 11/11/2015.
//  Copyright © 2015 Preetham. All rights reserved.
//

#import "SMProfileScreenController.h"

@interface SMProfileScreenController ()

@end

@implementation SMProfileScreenController

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.title = @"Profile";
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
