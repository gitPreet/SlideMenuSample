//
//  SMHomeScreenController.m
//  SideMenu
//
//  Created by Preetham Baliga on 11/11/2015.
//  Copyright © 2015 Preetham. All rights reserved.
//

#import "SMHomeScreenController.h"

@interface SMHomeScreenController ()

@end

@implementation SMHomeScreenController

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
