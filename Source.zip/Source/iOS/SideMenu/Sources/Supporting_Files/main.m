//
//  main.m
//  SideMenu
//
//  Created by Preetham Baliga on 11/11/2015.
//  Copyright © 2015 Preetham. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SMAppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SMAppDelegate class]));
    }
}
