//
//  SMDataTypes.h
//  SideMenu
//
//  Created by Preetham Baliga on 11/11/2015.
//  Copyright © 2015 Preetham. All rights reserved.
//

#ifndef SMDataTypes_h
#define SMDataTypes_h


#endif
