//
//  SMConstants.h
//  SideMenu
//
//  Created by Preetham Baliga on 11/11/2015.
//  Copyright © 2015 Preetham. All rights reserved.
//

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT NSString *const SMEmptyString;