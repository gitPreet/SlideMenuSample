//
//  SMNavigationController.h
//  SideMenu
//
//  Created by Preetham Baliga on 12/11/2015.
//

#import <UIKit/UIKit.h>
#import "SMMenuScreenController.h"
#import "SMBaseViewController.h"

@interface SMNavigationController : UINavigationController <UINavigationControllerDelegate>

@property (strong, nonatomic) SMMenuScreenController *menuScreenController;

+ (SMNavigationController *)sharedInstance;

- (void)setMenuScreenController:(SMMenuScreenController *)menuScreenController;

- (void)dismissMenu;

- (void)switchToViewController:(SMBaseViewController *)viewController;

@end
