//
//  SMFriendsDetailController.m
//  SideMenu
//
//  Created by Preetham Baliga on 13/11/2015.
//  Copyright © 2015 Preetham. All rights reserved.
//

#import "SMFriendsDetailController.h"
#import "SMNavigationController.h"

@interface SMFriendsDetailController ()

@end

@implementation SMFriendsDetailController

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.title = @"Detail";
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
