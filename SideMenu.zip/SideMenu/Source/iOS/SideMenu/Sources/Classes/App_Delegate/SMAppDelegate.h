//
//  AppDelegate.h
//  SideMenu
//
//  Created by Preetham Baliga on 11/11/2015.
//

#import <UIKit/UIKit.h>

@interface SMAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

