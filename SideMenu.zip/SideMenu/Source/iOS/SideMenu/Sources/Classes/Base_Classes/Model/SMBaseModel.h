//
//  SMBaseModel.h
//  SideMenu
//
//  Created by Preetham Baliga on 11/11/2015.
//

#import <Foundation/Foundation.h>

@interface SMBaseModel : NSObject

@end
