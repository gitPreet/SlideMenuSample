//
//  SMBaseCollectionViewCell.m
//  SideMenu
//
//  Created by Preetham Baliga on 11/11/2015.
//

#import "SMBaseCollectionViewCell.h"

@implementation SMBaseCollectionViewCell

- (void)awakeFromNib
{
    [super awakeFromNib];
}

- (void)prepareForReuse
{
    [super prepareForReuse];
}

- (void)setModel:(SMBaseModel *)model
{
    _model = model;
    [self updateUI];
}

- (void)updateUI
{
    
}

@end
